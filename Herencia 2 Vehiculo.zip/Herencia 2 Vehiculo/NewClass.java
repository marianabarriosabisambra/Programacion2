

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.text.DecimalFormat;


public class NewClass {
    public static void main(String[] args) {

Automovil automovil1 = new Automovil("28-06-1926", "WD3", "M27492010123456", "Mercedes", "Mercedes-AMG GT", 806900000);
        
        automovil1.mostrarLosDatos();
        
    }

}   
    class Vehiculo {
    private final String fecha_de_fabricacion;
    private final String VIN_chasis;
    private final String VIN_motor;
    
    
    public Vehiculo(String fecha_de_fabricacion, String VIN_chasis, String VIN_motor) {
        this.fecha_de_fabricacion = fecha_de_fabricacion;
        this.VIN_chasis = VIN_chasis;
        this.VIN_motor = VIN_motor;
    }

    public String obtener_fecha_de_fabricacion() {
        return fecha_de_fabricacion;    
    }
    
     public String obtener_VIN_chasis() {
        return VIN_chasis;
    }

    public String obtener_VIN_motor() {
        return VIN_motor;
    }
}

class Automovil extends Vehiculo {

    private final String marca;
    private final String modelo;
    private final double precio;

    public Automovil(String fecha_de_fabricacion, String VIN_chasis, String VIN_motor, String marca, String modelo, double precio) {
        super(fecha_de_fabricacion, VIN_chasis, VIN_motor);
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
    
    public String obtener_marca() {
        return marca;
    }

    public String obtener_modelo() {
        return modelo;
    }

    public double obtener_precio() {
        return precio;
    }
    
    public void mostrarLosDatos() {
        DecimalFormat formato = new DecimalFormat("#,###");
        System.out.println("Los Detalles del Automóvil:");
        System.out.println("Fecha de Fabricación: " + obtener_fecha_de_fabricacion());
        System.out.println("VIN del chasis: " +  obtener_VIN_chasis());
        System.out.println("VIN del Motor: " + obtener_VIN_motor());
        System.out.println("Marca: " + obtener_marca());
        System.out.println("Modelo: " + obtener_modelo());
        System.out.println("Precio: $COP " + formato.format(obtener_precio()));
    }
}
