class Vehiculo:
    def __init__(self,fecha_de_fabricacion,VIN_chasis,VIN_motor):
        self.fecha_de_fabricacion= fecha_de_fabricacion
        self.VIN_chasis=VIN_chasis
        self.VIN_motor=VIN_motor

    def obtener_fecha_de_fabricacion(self):
        return self.fecha_de_fabricacion
    
    def obtener_VIN_chasis(self):
        return self.VIN_chasis
    
    def obtener_VIN_motor(self):
        return self.VIN_motor
    

class Automovil(Vehiculo):
    def __init__(self, fecha_de_fabricacion, VIN_chasis, VIN_motor, marca, modelo, precio):
        super().__init__(fecha_de_fabricacion, VIN_chasis, VIN_motor)
        self.marca= marca
        self.modelo= modelo
        self.precio= precio

    def obtener_marca(self):
        return self.marca
    def obtener_modelo(self):
        return self.modelo
    def obtener_precio(self):
        return self.precio
    
    def mostrar_los_datos(self):
        print(f"Los Detalles del Automovil:")
        print(f"Fecha de Fabricacion: {self.obtener_fecha_de_fabricacion()}")
        print(f"VIN del chasis: {self.obtener_VIN_chasis()}")
        print(f"VIN del motor: {self.obtener_VIN_motor()}")
        print(f"Marca: {self.obtener_marca()}")
        print(f"Modelo: {self.obtener_modelo()}")
        print(f"Precio: $COP{self.obtener_precio()}")

Automovil_1= Automovil("28-06-1926", "WD3", "M27492010123456", "Mercedes", "Mercedes-AMGGT", 806900000)
Automovil_1.mostrar_los_datos()
