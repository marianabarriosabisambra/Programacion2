from datetime import datetime

class Cliente:
    def __init__(self, cedula, nombre, apellido, telefono, correo, direccion, fecha_nacimiento):
        self.cedula = cedula
        self.nombre = nombre
        self.apellido = apellido
        self.telefono = telefono
        self.correo = correo
        self.direccion = direccion
        self.fecha_nacimiento = fecha_nacimiento

    def obtener_datos(self):
        return (f"Cédula: {self.cedula}, Nombre: {self.nombre}, Apellido: {self.apellido}, "
                f"Teléfono: {self.telefono}, Correo: {self.correo}, Dirección: {self.direccion}, "
                f"Fecha de nacimiento: {self.fecha_nacimiento}")

    def calcular_edad(self):
        
        año_nacimiento = int(self.fecha_nacimiento[:4])
        
        año_actual = datetime.now().year
        
        return año_actual - año_nacimiento

    def obtener_mensaje(self):
        edad = self.calcular_edad()
        return f"Mi nombre es {self.nombre} {self.apellido} y vivo en {self.direccion} y tengo {edad} años de edad."


cliente = Cliente(
    "12347623",
    "Lucia",
    "Abisambra",
    "9647396531",
    "luciaabisambra@example.com",
    "Calle imaginaria 433",
    "2006/10/10"
)

print(cliente.obtener_mensaje())